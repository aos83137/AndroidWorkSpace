package com.example.yongseok.questionapp;

import android.content.Context;
import android.view.View;

public interface ClickListener {
    public void onItemClick(View v, int position);
}
